#ifndef GESTURE_H
#define GESTURE_H

void keyboardClick(unsigned char key, int x, int y);

void arrowKey(int key, int x, int y);

void mouseCoordinate(int x, int y);

void mouseWheelFunc(int button, int state, int x, int y);

#endif
