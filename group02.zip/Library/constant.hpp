#pragma once
#ifndef  CONSTANT
	#define WINDOW_WIDTH 1024
	#define WINDOW_HEIGHT 1024
	#define NUMBER_OF_ROCK 500
	#define STAR_TRACK_SIZE 10
#endif
