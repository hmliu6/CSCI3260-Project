#ifndef GUIFUNCTION_H
#define GUIFUNCTION_H


using namespace std;


void myGlutReshape(int w, int h);
void setupGLUI();

#endif