#pragma once

typedef struct CameraPosition {
	float x, y, z,
		startX, startY, startZ;
}CameraPosition;